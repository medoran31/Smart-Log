# SMARTLOG — Socle technique (Étape 1 de la feuille de route)

Ce dossier contient l'amorce de code correspondant à l'architecture validée
dans l'étude (Phase 1 et Phase 2) : une solution .NET 8 en 4 couches.

```
SMARTLOG.sln
src/
  SMARTLOG.Domain/     → entités métier pures, aucune dépendance externe
  SMARTLOG.Data/        → EF Core + SQLite (DbContext, migrations à venir)
  SMARTLOG.Services/    → logique métier (ex. recalcul d'un avenant)
  SMARTLOG.App/         → application WPF (fenêtre principale, MVVM)
```

## Ce qui est déjà en place

- Les entités du schéma relationnel validé (Projet, Marché, Avenant,
  Attachement/LigneAttachement, Situation, Tâche/LiaisonTache, Réserve,
  Document, Courrier, Alerte, Utilisateur/Rôle, JournalAction).
- Le `SmartlogDbContext` avec les contraintes principales (précision des
  décimaux, unicité du code projet, relations one-to-many/one-to-one).
- La règle métier centrale du cahier des charges : **la validation d'un
  avenant est le seul point du code qui modifie `Projet.MontantActualise`
  et `Projet.DelaiActualiseJours`**, avec journalisation systématique
  (`AvenantService` + `JournalService`).
- La fenêtre principale WPF : barre supérieure (recherche, notifications,
  thème), menu latéral avec les 14 modules, zone de contenu prête à
  recevoir une `UserControl` par module.

## Ce qui reste à faire (prochains lots)

- Générer la première migration EF Core (`Add-Migration Initial`) une fois
  le projet ouvert sous Windows avec le SDK .NET 8 installé.
- Développer une `UserControl` + `ViewModel` par module (Tableau de bord,
  Fiche projet, Avenants...), chacune branchée sur les services existants.
- Implémenter les services manquants (`SituationService`,
  `PlanningService` avec calcul du chemin critique, `ReserveService`,
  `AlerteService`) en suivant le même modèle que `AvenantService` :
  aucune valeur dérivée n'est jamais modifiée ailleurs que dans son service
  dédié.
- Ajouter le moteur de modèles documentaires transversal (génération de
  PV/rapports à partir d'un modèle + données projet).

## Ouvrir et lancer le projet

Ce code a été écrit sans environnement .NET disponible ici (pas de SDK, pas
de réseau dans ce conteneur) : il n'a donc pas été compilé automatiquement.
Sur votre poste Windows avec le **SDK .NET 8** installé :

```powershell
cd SMARTLOG
dotnet restore
dotnet ef migrations add Initial --project src/SMARTLOG.Data --startup-project src/SMARTLOG.App
dotnet run --project src/SMARTLOG.App
```

(`dotnet-ef` s'installe au besoin avec `dotnet tool install --global dotnet-ef`.)

La base SQLite est créée automatiquement au premier lancement dans
`%LocalAppData%\Smartlog\smartlog.db`.
