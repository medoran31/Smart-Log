using System.IO;
using System.Windows;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Smartlog.App.ViewModels;
using Smartlog.App.Views;
using Smartlog.Data;
using Smartlog.Services;

namespace Smartlog.App;

public partial class App : Application
{
    public static IServiceProvider Services { get; private set; } = null!;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        var dossierDonnees = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "Smartlog");
        Directory.CreateDirectory(dossierDonnees);
        var cheminBase = Path.Combine(dossierDonnees, "smartlog.db");

        var services = new ServiceCollection();

        services.AddDbContext<SmartlogDbContext>(options =>
            options.UseSqlite($"Data Source={cheminBase}"));

        services.AddScoped<IJournalService, JournalService>();
        services.AddScoped<IAvenantService, AvenantService>();

        services.AddSingleton<MainViewModel>();
        services.AddSingleton<MainWindow>();

        Services = services.BuildServiceProvider();

        // Applique les migrations en attente à chaque démarrage : c'est le
        // mécanisme de mise à jour du schéma demandé au §9 du cahier des charges.
        using (var scope = Services.CreateScope())
        {
            scope.ServiceProvider.GetRequiredService<SmartlogDbContext>().Database.Migrate();
        }

        Services.GetRequiredService<MainWindow>().Show();
    }
}
