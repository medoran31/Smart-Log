using System.Collections.ObjectModel;

namespace Smartlog.App.ViewModels;

public record ElementMenu(string Libelle, string Icone);

/// <summary>
/// Pilote le menu latéral de la fenêtre principale (§10 du cahier des
/// charges : "navigation claire à travers un menu latéral professionnel").
/// La sélection d'un élément changera la vue affichée dans le volet central
/// (à brancher sur un ContentControl + DataTemplate par module).
/// </summary>
public class MainViewModel : ViewModelBase
{
    public ObservableCollection<ElementMenu> ElementsMenu { get; } = new()
    {
        new("Tableau de bord", "📊"),
        new("Mes projets", "🏗️"),
        new("Fiche projet", "📁"),
        new("Marché et contrats", "📄"),
        new("Avenants", "✏️"),
        new("Attachements et situations", "💰"),
        new("Suivi technique", "🧱"),
        new("Réserves", "⚠️"),
        new("Planning", "📅"),
        new("Finances", "📈"),
        new("Documents", "🗂️"),
        new("Courrier", "✉️"),
        new("Assistant IA", "🤖"),
        new("Paramètres", "⚙️"),
    };

    private ElementMenu? _elementSelectionne;
    public ElementMenu? ElementSelectionne
    {
        get => _elementSelectionne;
        set => SetField(ref _elementSelectionne, value);
    }

    public MainViewModel()
    {
        ElementSelectionne = ElementsMenu.First();
    }
}
