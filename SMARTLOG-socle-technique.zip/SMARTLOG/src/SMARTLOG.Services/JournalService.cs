using System.Text.Json;
using Smartlog.Data;
using Smartlog.Domain.Entities;

namespace Smartlog.Services;

public class JournalService : IJournalService
{
    private readonly SmartlogDbContext _db;

    public JournalService(SmartlogDbContext db) => _db = db;

    public async Task EnregistrerAsync(
        Guid utilisateurId,
        string entiteType,
        Guid entiteId,
        string action,
        object? valeurAvant,
        object? valeurApres,
        CancellationToken ct = default)
    {
        _db.JournalActions.Add(new JournalAction
        {
            UtilisateurId = utilisateurId,
            EntiteType = entiteType,
            EntiteId = entiteId,
            Action = action,
            ValeurAvantJson = valeurAvant is null ? null : JsonSerializer.Serialize(valeurAvant),
            ValeurApresJson = valeurApres is null ? null : JsonSerializer.Serialize(valeurApres),
            DateAction = DateTime.UtcNow
        });

        await _db.SaveChangesAsync(ct);
    }
}
