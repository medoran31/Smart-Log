using Smartlog.Domain.Entities;

namespace Smartlog.Services;

public interface IAvenantService
{
    /// <summary>
    /// Valide un avenant brouillon : recalcule MontantActualise et
    /// DelaiActualiseJours sur le Projet associé, journalise l'opération,
    /// et verrouille l'avenant (il ne redevient modifiable que par
    /// annulation explicite, elle aussi journalisée).
    /// </summary>
    Task<Projet> ValiderAsync(Guid avenantId, Guid utilisateurId, CancellationToken ct = default);

    /// <summary>
    /// Annule un avenant déjà validé : recalcule le projet comme si
    /// l'avenant n'avait jamais existé. Opération explicite et journalisée,
    /// jamais silencieuse (§6 du cahier des charges).
    /// </summary>
    Task<Projet> AnnulerAsync(Guid avenantId, Guid utilisateurId, CancellationToken ct = default);
}
