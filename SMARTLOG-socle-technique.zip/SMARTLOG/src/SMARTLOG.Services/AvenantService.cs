using Microsoft.EntityFrameworkCore;
using Smartlog.Data;
using Smartlog.Domain.Entities;
using Smartlog.Domain.Enums;

namespace Smartlog.Services;

/// <summary>
/// Implémente la règle centrale du §6 du cahier des charges :
/// "Lorsqu'un avenant est ajouté, recalculer le montant actualisé et
/// le délai contractuel." Le montant/délai du Projet n'est JAMAIS
/// modifié ailleurs que dans ce service.
/// </summary>
public class AvenantService : IAvenantService
{
    private readonly SmartlogDbContext _db;
    private readonly IJournalService _journal;

    public AvenantService(SmartlogDbContext db, IJournalService journal)
    {
        _db = db;
        _journal = journal;
    }

    public async Task<Projet> ValiderAsync(Guid avenantId, Guid utilisateurId, CancellationToken ct = default)
    {
        var avenant = await _db.Avenants
            .Include(a => a.Marche)
            .ThenInclude(m => m!.Projet)
            .FirstOrDefaultAsync(a => a.Id == avenantId, ct)
            ?? throw new InvalidOperationException($"Avenant {avenantId} introuvable.");

        if (avenant.Statut != StatutAvenant.Brouillon)
            throw new InvalidOperationException("Seul un avenant en brouillon peut être validé.");

        var projet = avenant.Marche!.Projet!;
        var avant = new { projet.MontantActualise, projet.DelaiActualiseJours };

        projet.MontantActualise += avenant.MontantDelta;
        projet.DelaiActualiseJours += avenant.DelaiDeltaJours;
        if (projet.DateCommencement is not null)
        {
            projet.DatePrevisionnelleAchevement =
                projet.DateCommencement.Value.AddDays(projet.DelaiActualiseJours);
        }

        avenant.Statut = StatutAvenant.Valide;
        avenant.DateValidation = DateOnly.FromDateTime(DateTime.UtcNow);

        await _db.SaveChangesAsync(ct);

        await _journal.EnregistrerAsync(
            utilisateurId, nameof(Projet), projet.Id, "RecalculAvenant",
            avant,
            new { projet.MontantActualise, projet.DelaiActualiseJours },
            ct);

        return projet;
    }

    public async Task<Projet> AnnulerAsync(Guid avenantId, Guid utilisateurId, CancellationToken ct = default)
    {
        var avenant = await _db.Avenants
            .Include(a => a.Marche)
            .ThenInclude(m => m!.Projet)
            .FirstOrDefaultAsync(a => a.Id == avenantId, ct)
            ?? throw new InvalidOperationException($"Avenant {avenantId} introuvable.");

        if (avenant.Statut != StatutAvenant.Valide)
            throw new InvalidOperationException("Seul un avenant validé peut être annulé.");

        var projet = avenant.Marche!.Projet!;
        var avant = new { projet.MontantActualise, projet.DelaiActualiseJours };

        projet.MontantActualise -= avenant.MontantDelta;
        projet.DelaiActualiseJours -= avenant.DelaiDeltaJours;

        avenant.Statut = StatutAvenant.Annule;

        await _db.SaveChangesAsync(ct);

        await _journal.EnregistrerAsync(
            utilisateurId, nameof(Projet), projet.Id, "AnnulationAvenant",
            avant,
            new { projet.MontantActualise, projet.DelaiActualiseJours },
            ct);

        return projet;
    }
}
