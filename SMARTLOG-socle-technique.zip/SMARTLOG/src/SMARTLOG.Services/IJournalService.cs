namespace Smartlog.Services;

/// <summary>
/// Point d'entrée unique de la traçabilité (§6 et §12 du cahier des charges :
/// "historique des opérations... qui a modifié quoi et à quelle date").
/// Tout service métier qui modifie une entité doit passer par ici.
/// </summary>
public interface IJournalService
{
    Task EnregistrerAsync(
        Guid utilisateurId,
        string entiteType,
        Guid entiteId,
        string action,
        object? valeurAvant,
        object? valeurApres,
        CancellationToken ct = default);
}
